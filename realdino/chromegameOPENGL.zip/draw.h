#include <GL/freeglut_std.h>
#include <cmath>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <vector>

void drawDino(int w, int walk, bool isDucking);
void drawTree(float _location);
void android1();
void android2();
void android3();