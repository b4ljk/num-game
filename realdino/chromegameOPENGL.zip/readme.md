# Заавар
Дараах command-г ашиглаж компайлднуу

`g++ main.cpp draw.cpp -o dino -lGL -lGLU -lglut && ./dino`